<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Selamta Transport LLC - Safe rides, reliable service, compassionate care. Non-emergency medical and student transportation.">
<title>Selamta Transport LLC | Safe Rides. Reliable Service. Compassionate Care.</title>
<!--<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">-->
<link rel="stylesheet" href="fontawesome/css/all.min.css?v=2.3">
<link rel="stylesheet" href="css/demo.css?v=2.3">
<!-- <style>
:root{--navy:#062b52;--navy2:#031d38;--gold:#e6ad22;--gold2:#f6c445;--ink:#17283b;--muted:#64748b;--light:#f5f8fb;--white:#fff;--line:#e4ebf2;--shadow:0 12px 35px rgba(4,32,59,.10)}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:Inter,Arial,sans-serif;color:var(--ink);background:#fff;line-height:1.6}a{text-decoration:none;color:inherit}img{max-width:100%;display:block}.container{width:min(1180px,92%);margin:auto}
.top{background:var(--navy2);color:#fff;font-size:13px}.top .container{min-height:42px;display:flex;align-items:center;justify-content:space-between;gap:18px}.top-left,.social{display:flex;gap:18px;align-items:center}.social a{opacity:.9}.social a:hover{color:var(--gold2)}
.nav{position:sticky;top:0;z-index:20;background:#fff;border-bottom:1px solid var(--line);box-shadow:0 3px 14px rgba(0,0,0,.04)}.nav .container{height:78px;display:flex;align-items:center;justify-content:space-between}.brand{display:flex;align-items:center;gap:10px}.brand-mark{font-family:Georgia,serif;font-size:57px;font-weight:700;font-style:italic;line-height:.7;color:var(--gold);text-shadow:2px 1px 0 #111}.brand-text strong{display:block;font-family:Georgia,serif;font-size:23px;letter-spacing:.5px}.brand-text span{font-size:11px;font-weight:800;letter-spacing:1.4px}.links{display:flex;align-items:center;gap:28px;font-size:13px;font-weight:700}.links a:hover,.links a.active{color:var(--gold)}.menu{display:none;border:0;background:none;font-size:28px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:12px 22px;border-radius:30px;background:var(--gold);color:#111;font-weight:800;font-size:13px;border:1px solid var(--gold);transition:.2s}.btn:hover{transform:translateY(-1px);background:var(--gold2)}.btn.dark{background:var(--navy);color:#fff;border-color:var(--navy)}.btn.outline{background:transparent;color:#fff;border-color:#fff}
.hero{min-height:570px;position:relative;background:#061d35}.hero-image{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}.hero-overlay{position:absolute;inset:0;background:linear-gradient(90deg,rgba(2,23,43,.92) 0%,rgba(2,23,43,.72) 43%,rgba(2,23,43,.18) 76%)}.hero .container{position:relative;z-index:1;min-height:570px;display:flex;align-items:center}.hero-copy{max-width:590px;color:#fff;padding:60px 0}.eyebrow{color:var(--gold2);font-size:13px;font-weight:800;letter-spacing:2px;text-transform:uppercase}.hero h1{font-size:clamp(42px,6vw,70px);line-height:1.03;margin:15px 0}.hero h1 span{color:var(--gold2)}.hero p{font-size:17px;max-width:520px;color:#edf3f8;margin-bottom:28px}.actions{display:flex;gap:12px;flex-wrap:wrap}
section{padding:78px 0}.section-head{margin-bottom:35px}.section-head.center{text-align:center}.section-head .eyebrow{font-size:11px}.section-head h2{font-size:34px;line-height:1.15;margin:8px 0 10px;color:var(--navy)}.section-head p{color:var(--muted);max-width:720px}.center p{margin-left:auto;margin-right:auto}
.about{display:grid;grid-template-columns:1fr 1.05fr .7fr;gap:32px;align-items:center}.about-photo{height:365px;object-fit:cover;border-radius:12px;box-shadow:var(--shadow)}.about-copy h2{margin:5px 0 12px;color:var(--navy);font-size:32px;line-height:1.15}.about-copy p{color:var(--muted);font-size:14px}.values{background:var(--light);border-radius:12px;padding:25px}.value{display:flex;gap:13px;margin:0 0 19px}.value:last-child{margin-bottom:0}.icon{width:34px;height:34px;flex:0 0 34px;border-radius:50%;display:grid;place-items:center;background:#fff4cf;color:var(--navy);font-weight:800}.value b{display:block;font-size:13px;color:var(--navy)}.value span{font-size:11px;color:var(--muted)}
.mission{background:linear-gradient(180deg,#f8fafc,#eef5fa)}.pill-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:0}.pill{padding:8px 27px;border-right:1px solid var(--line)}.pill:last-child{border:0}.pill h3{font-size:18px;color:var(--navy);margin:5px 0 12px}.pill p,.pill li{font-size:11.5px;color:var(--muted)}.pill ul{padding-left:17px;margin:0}
.services{background:#fbfdff}.service-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:18px}.card{background:#fff;border:1px solid var(--line);border-radius:10px;overflow:hidden;box-shadow:0 7px 24px rgba(5,35,60,.06)}.service-img{width:100%;height:145px;object-fit:cover}.card-body{padding:18px}.badge{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:var(--navy);color:var(--gold2);margin-top:-37px;position:relative;border:3px solid #fff;font-weight:800}.card h3{font-size:14px;color:var(--navy);margin:10px 0 6px}.card p{font-size:11px;color:var(--muted);margin:0}.small-card{padding:20px}.small-card h3{margin:0 0 7px}.promise{grid-column:span 2;background:#fff8e8;display:flex;align-items:center;gap:20px;padding:25px;border-radius:10px;border:1px solid #f1e1b6}.promise .road{font-size:42px;color:var(--navy)}
/* Change the Why Choose background image here if desired: images/selamta-ambulatory.jpg */
.why{background:linear-gradient(90deg,rgba(2,29,56,.97),rgba(2,29,56,.90)),url('images/selamta-student.jpg') center/cover;color:#fff}.why-grid{display:grid;grid-template-columns:1fr 1.25fr;gap:50px;align-items:center}.why h2{font-size:34px;margin:8px 0 14px}.why h2 span{color:var(--gold2)}.why p{color:#dce8f2;font-size:14px}.reason-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:22px}.reason{text-align:center}.reason .big{font-size:28px;color:var(--gold2)}.reason b{display:block;font-size:12px;margin-top:4px}.reason span{font-size:10px;color:#c6d5e2}
.request{display:grid;grid-template-columns:1fr 1fr;gap:25px}.panel{border:1px solid var(--line);border-radius:10px;padding:28px;background:#fff;box-shadow:var(--shadow)}.panel h2{margin:0;color:var(--navy);font-size:25px}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:13px}.field{margin-top:13px}.field label{display:block;font-size:10px;font-weight:700;color:var(--muted);margin-bottom:5px}.field input,.field select,.field textarea{width:100%;border:1px solid #d8e1e9;border-radius:5px;padding:11px 12px;font:inherit;font-size:12px;outline:none}.field textarea{min-height:90px;resize:vertical}.field input:focus,.field select:focus,.field textarea:focus{border-color:var(--gold)}.full{grid-column:1/-1}.fleet-photo{height:250px;width:100%;object-fit:cover;border-radius:8px;margin-top:18px}.fleet-features{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;text-align:center;margin-top:15px}.fleet-features b{display:block;font-size:10px;color:var(--navy)}.fleet-features span{font-size:9px;color:var(--muted)}
.contact{background:var(--light)}.contact-grid{display:grid;grid-template-columns:1fr 1fr;gap:25px}.contact-card{padding:30px;background:#fff;border-radius:10px}.contact-card h2{color:var(--navy);margin-top:0}.contact-item{display:flex;gap:13px;margin:18px 0;font-size:14px}.contact-item .icon{background:#eef4fa}.social-big{display:flex;gap:10px;flex-wrap:wrap;margin-top:20px}.social-big a{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:var(--navy);color:#fff;font-size:12px;font-weight:700}.social-big a:hover{background:var(--gold);color:#111}
.footer{background:var(--navy2);color:#dce7f0;padding:45px 0 20px}.footer-grid{display:grid;grid-template-columns:1.6fr 1fr 1fr 1fr;gap:35px}.footer .brand-text strong{color:#fff}.footer h4{color:#fff;margin:0 0 12px}.footer a,.footer p{font-size:11px;color:#b8c9d8}.copyright{border-top:1px solid #34516d;margin-top:30px;padding-top:17px;text-align:center;font-size:10px;color:#9eb3c5}
@media(max-width:980px){.links{gap:14px}.about{grid-template-columns:1fr 1fr}.values{grid-column:1/-1}.service-grid{grid-template-columns:repeat(2,1fr)}.pill-grid{grid-template-columns:repeat(2,1fr)}.pill{border-bottom:1px solid var(--line);padding:20px}.why-grid,.request,.contact-grid{grid-template-columns:1fr}.footer-grid{grid-template-columns:1fr 1fr}}
@media(max-width:720px){.top .container{justify-content:center}.top-left span:nth-child(3),.social{display:none}.nav .container{height:68px}.links{display:none;position:absolute;left:0;right:0;top:68px;background:#fff;padding:18px 6%;flex-direction:column;align-items:flex-start;border-bottom:1px solid var(--line)}.links.open{display:flex}.menu{display:block}.hero,.hero .container{min-height:520px}.hero-copy{padding:40px 0}.hero h1{font-size:44px}.about{grid-template-columns:1fr}.about-photo{height:300px}.service-grid,.pill-grid,.reason-grid{grid-template-columns:1fr}.promise{grid-column:auto}.form-grid{grid-template-columns:1fr}.full{grid-column:auto}.fleet-features{grid-template-columns:repeat(2,1fr)}.footer-grid{grid-template-columns:1fr}section{padding:58px 0}}
</style> -->
</head>
<body>

  <!-- <div class="top">
    <div class="container">
      <div class="top-left">
        <span>☎ &nbsp;+1 913 568 0962</span><span>✉ &nbsp;lakmulu@yahoo.com</span><span>📍 &nbsp;8747 Noland Rd, Lenexa, Ks 66215</span>
      </div>
      <div class="social">
        <a href="#" aria-label="X"><i class="fa-brands fa-x-twitter"></i></a>
        <a href="#" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
        <a href="#" aria-label="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
        <a href="#" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
        <a href="#" aria-label="TikTok"><i class="fa-brands fa-tiktok"></i></a>
      </div>
    </div>
  </div> -->

  <nav class="nav">
    <div class="container">
      <!-- <a class="brand" href="#home"><span class="brand-mark">S</span><span class="brand-text"><strong>SELAMTA</strong><span>TRANSPORT LLC</span></span></a> -->
      <a class="brand" href="#home"><img src="images/logo_250_v2.png" class="brand-mark_img"></img><span class="brand-text"><strong>SELAMTA</strong><span>TRANSPORT LLC</span></span></a>
      <button class="menu" onclick="document.querySelector('.links').classList.toggle('open')" aria-label="Open menu">☰</button>
      <div class="links">
        <a class="active" href="#home">Home</a>
        <a href="#about">About Us</a>
        <a href="#services">Services</a>
        <!-- <a href="#why">Why Choose Us</a> -->
        <a href="#why">Why Us</a>
        <a href="#mission">Mission</a>
        <a href="#contact">Contact</a>
        <!-- <a class="btn" href="#request">Request Service →</a> -->
        <!-- <a class="btn" href="#request">Call Us: +1 913 568 0962</a> -->
        <a class="call-us" href="tel:+19135680962">
          <span class="call-title">
              <i class="fas fa-phone-alt"></i> CALL US
          </span>
          <strong>+1 913 568 0962</strong>
        </a>
      </div>
    </div>
  </nav>

  <section class="hero" id="home">
    <!-- Subtle background glow accent -->
    <div class="hero-bg-glow"></div>

    <div class="container hero-layout">
      <!-- Left Column: Interactive Brand Logo Card -->
      <div class="hero-brand-card">
        <div class="logo-wrapper">
          <img class="hero-logo" src="images/selamta-logo.png" alt="Selamta Transport LLC Logo">
        </div>
      </div>

      <!-- Right Column: Text Content -->
      <div class="hero-copy">
        <h1>Your Destination.<br><span>Our Commitment.</span></h1>
        <p>Safe, reliable, and compassionate transportation for your medical and healthcare needs.</p>
        
        <div class="actions">
          <a class="btn call-btn" href="tel:+19135680962">
            <i class="fas fa-phone-alt btn-icon"></i>
            <span class="btn-text">
              <span class="label">CALL US</span>
              <strong class="number">+1 913 568 0962</strong>
            </span>
          </a>
          <a class="btn" href="#request">Request a Service →</a>
          <a class="btn outline" href="#about">Learn More</a>
        </div>
      </div>
    </div>
  </section>

  <!-- <section class="hero" id="home">
    <img class="hero-image" src="images/selamta-home2.png" alt="Selamta Transport non-emergency medical transportation">
    <div class="hero-overlay"></div>
    <div class="container">
      <div class="hero-copy">
        <h1>Your Destination.<br><span>Our Commitment.</span></h1>
        <p>Safe, reliable, and compassionate transportation for your medical and healthcare needs.</p>
        <div class="actions">
          <a class="btn call-btn" href="tel:+19135680962">
            <i class="fas fa-phone-alt btn-icon"></i>
            <span class="btn-text">
              <span class="label">CALL US</span>
              <strong class="number">+1 913 568 0962</strong>
            </span>
          </a>
          <a class="btn" href="#request">Request a Service →</a>
          <a class="btn outline" href="#about">Learn More</a>
        </div>
      </div>
    </div>
  </section> -->

  <section id="about">
    <div class="container about about_2">
      <!-- <img class="about-photo" src='images/selamta-wheelchair.jpg' alt="Selamta Transport wheelchair transportation"> -->
      <div class="about-copy">
        <div class="eyebrow_v2">About Us</div>
        <h3>Welcome to Selamta Transport LLC</h3>
        <p>At Selamta Transport LLC, we are dedicated to providing safe, dependable, and compassionate Non-Emergency Medical Transportation (NEMT) services for individuals who need reliable transportation to healthcare appointments and essential medical services.</p>
        <p>We understand that getting to a medical appointment can sometimes be challenging. Our goal is to make transportation easier by providing professional service that puts the needs, comfort, and dignity of our passengers first.</p>
        <p>Our team is committed to providing a respectful and comfortable transportation experience from the moment we pick you up until you safely reach your destination.</p>
        <a class="btn dark" href="#mission">Our Commitment →</a>
      </div>
      <!-- <img class="about-photo" src='images/selamta-wheelchair.jpg' alt="Selamta Transport wheelchair transportation"> -->
      <div class="values">
        <span class="eyebrow_v2">Our Commitment</span>
        <div class="value"><div class="icon">✓</div><div><b>Safety</b><span>Your safety is our highest priority.</span></div></div>
        <div class="value"><div class="icon">✓</div><div><b>Reliability</b><span>We strive to provide dependable, timely service.</span></div></div>
        <div class="value"><div class="icon">♡</div><div><b>Respect</b><span>Every passenger is treated with dignity and courtesy.</span></div></div>
        <div class="value"><div class="icon">♥</div><div><b>Compassion</b><span>We understand that medical transportation can be stressful.</span></div></div>
        <div class="value"><div class="icon">★</div><div><b>Professionalism</b><span>We deliver quality service and build trust.</span></div></div>
      </div>
    </div>
  </section>

  <section class="services" id="services">
    <div class="container">
      <div class="section-head">
        <div class="eyebrow_v2">Our Services</div>
        <!-- <h2>Non-Emergency Medical Transportation</h2> -->
        <p>We provide dependable transportation for individuals who need assistance getting to healthcare, school, workplaces, social events, and other essential appointments.</p>
      </div>
      <div class="service-grid">
        <article class="card"><img class="service-img" src='images/selamta-wheelchair.jpg' alt="Wheelchair transportation"><div class="card-body"><div class="badge">♿</div><h3>Wheelchair Transportation</h3><p>Accessible transportation for passengers who require wheelchair assistance, subject to vehicle availability and scheduling.</p></div></article>
        <article class="card"><img class="service-img" src='images/selamta-ambulatory.jpg' alt="Ambulatory transportation"><div class="card-body"><div class="badge">♿</div><h3>Ambulatory Transportation</h3><p>Safe and comfortable transportation for passengers who can walk independently or with a cane, walker, or other mobility aid.</p></div></article>
        <article class="card"><img class="service-img" src='images/selamta-stretcher.jpg' alt="Stretcher transportation"><div class="card-body"><div class="badge">▣</div><h3>Stretcher Transportation</h3><p>Non-emergency stretcher transportation for passengers who are unable to travel safely in a standard seated position, subject to availability and eligibility.</p></div></article>
        <article class="card"><img class="service-img" src='images/selamta-student.jpg' alt="Student transportation"><div class="card-body"><div class="badge">▣</div><h3>Student Transportation</h3><p>Safe, reliable, and professional transportation for students traveling to school, educational programs, appointments, and other approved destinations.</p></div></article>
        <!-- <article class="card small-card"><div class="badge">♡</div><h3>Medical Appointments</h3><p>Reliable transportation to and from doctor visits, specialist appointments, and other healthcare services.</p></article>
        <article class="card small-card"><div class="badge">◫</div><h3>Dialysis Transportation</h3><p>Dependable transportation for individuals who require regular dialysis appointments.</p></article>
        <article class="card small-card"><div class="badge">⚕</div><h3>Therapy & Rehabilitation</h3><p>Transportation to physical therapy, occupational therapy, rehabilitation, and other scheduled treatment services.</p></article>
        <article class="card small-card"><div class="badge">▥</div><h3>Hospital & Clinic Transportation</h3><p>Transportation to and from hospitals, clinics, outpatient centers, and healthcare facilities for scheduled visits.</p></article>
        <article class="card small-card"><div class="badge">⌂</div><h3>Hospital Discharge & Return</h3><p>Assistance with transportation home after a scheduled hospital or medical facility discharge, when appropriate.</p></article>
        <article class="card small-card"><div class="badge">▦</div><h3>Scheduled & Recurring Trips</h3><p>Scheduled transportation needs, including recurring medical appointments, subject to availability and requirements.</p></article>
        <div class="promise"><div class="road">➜</div><div><h3>Our Service Promise</h3><p>Safe transportation. Reliable service.<br><strong>Compassionate care.</strong></p></div></div> -->
      </div>
    </div>
  </section>

  <section class="services" id="services">
    <div class="container">
      <div class="section-head">
        <div class="eyebrow_v2">Where are you traveling from and going to?</div>
        <!-- <p>We provide dependable transportation for individuals who need ...</p> -->
      </div>
      <div class="service-grid">
        <!-- <article class="card"><img class="service-img" src='images/workplaces.jpeg' alt="Workplaces transportation"><div class="card-body"><div class="badge">♿</div><h3>Wheelchair Transportation</h3><p>Accessible transportation for passengers who require wheelchair assistance, subject to vehicle availability and scheduling.</p></div></article> -->
        <!-- <article class="card small-card"><div class="badge">♡</div><h3>Medical Appointments</h3><p>Reliable transportation to and from doctor visits, specialist appointments, and other healthcare services.</p></article>
        <article class="card small-card"><div class="badge">◫</div><h3>Dialysis Transportation</h3><p>Dependable transportation for individuals who require regular dialysis appointments.</p></article>
        <article class="card small-card"><div class="badge">⚕</div><h3>Therapy & Rehabilitation</h3><p>Transportation to physical therapy, occupational therapy, rehabilitation, and other scheduled treatment services.</p></article>
        <article class="card small-card"><div class="badge">▥</div><h3>Hospital & Clinic Transportation</h3><p>Transportation to and from hospitals, clinics, outpatient centers, and healthcare facilities for scheduled visits.</p></article>
        <article class="card small-card"><div class="badge">⌂</div><h3>Hospital Discharge & Return</h3><p>Assistance with transportation home after a scheduled hospital or medical facility discharge, when appropriate.</p></article>
        <article class="card small-card"><div class="badge">▦</div><h3>Scheduled & Recurring Trips</h3><p>Scheduled transportation needs, including recurring medical appointments, subject to availability and requirements.</p></article>
        
        <article class="card small-card">
          <div class="badge">▦</div>
          <h3>Schools</h3>
          <p>Safe, reliable daily student pickups and drop-offs ensuring students arrive at school on time and return home safely.</p>
        </article>

        <article class="card small-card">
          <div class="badge">▦</div>
          <h3>Social Events</h3>
          <p>Convenient group transit for weddings, family gatherings, religious services, and community outings without parking stress.</p>
        </article>

        <article class="card small-card">
          <div class="badge">▦</div>
          <h3>Workplaces</h3>
          <p>Dependable commuter transport for corporate teams, shift workers, and recurring employee shuttle needs.</p>
        </article> -->
        <!-- <div class="promise"><div class="road">➜</div><div><h3>Our Service Promise</h3><p>Safe transportation. Reliable service.<br><strong>Compassionate care.</strong></p></div></div> -->
        
        <article class="card">
          <!-- <img class="service-img" src="images/adult.jpeg" alt="Medical Appointments transportation"> -->
          <div class="card-body">
            <div class="badge_2"><i class="fa-solid fa-user-doctor"></i></div>
            <h3>Medical Appointments</h3>
            <p>Reliable transportation to and from doctor visits, specialist appointments, and other healthcare services.</p>
          </div>
        </article>

        <article class="card">
          <!-- <img class="service-img" src="images/departure.jpeg" alt="Dialysis Transportation"> -->
          <div class="card-body">
            <div class="badge_2"><i class="fa-solid fa-notes-medical"></i></div>
            <h3>Dialysis Transportation</h3>
            <p>Dependable transportation for individuals who require regular dialysis appointments.</p>
          </div>
        </article>

        <article class="card">
          <!-- <img class="service-img" src="images/departure.jpeg" alt="Therapy and Rehabilitation transportation"> -->
          <div class="card-body">
            <div class="badge_2"><i class="fa-solid fa-hospital-user"></i></div>
            <h3>Therapy &amp; Rehabilitation</h3>
            <p>Transportation to physical therapy, occupational therapy, rehabilitation, and other scheduled treatment services.</p>
          </div>
        </article>

        <article class="card">
          <!-- <img class="service-img" src="images/departure.jpeg" alt="Hospital and Clinic Transportation"> -->
          <div class="card-body">
            <div class="badge_2"><i class="fa-solid fa-clinic-medical"></i></div>
            <h3>Hospital &amp; Clinic Transportation</h3>
            <p>Transportation to and from hospitals, clinics, outpatient centers, and healthcare facilities for scheduled visits.</p>
          </div>
        </article>

        <article class="card">
          <!-- <img class="service-img" src="images/departure.jpeg" alt="Hospital Discharge and Return transportation"> -->
          <div class="card-body">
            <div class="badge_2"><i class="fa-solid fa-house-medical"></i></div>
            <h3>Hospital Discharge &amp; Return</h3>
            <p>Assistance with transportation home after a scheduled hospital or medical facility discharge, when appropriate.</p>
          </div>
        </article>

        <article class="card">
          <!-- <img class="service-img" src="images/departure.jpeg" alt="Scheduled and Recurring Trips"> -->
          <div class="card-body">
            <div class="badge_2"><i class="fa-solid fa-calendar-check"></i></div>
            <h3>Scheduled &amp; Recurring Trips</h3>
            <p>Scheduled transportation needs, including recurring medical appointments, subject to availability and requirements.</p>
          </div>
        </article>

        <article class="card">
          <!-- <img class="service-img" src="images/selamta-student.jpg" alt="Schools transportation"> -->
          <div class="card-body">
            <div class="badge_2"><i class="fa-solid fa-school"></i></div>
            <h3>Schools</h3>
            <p>Safe, reliable daily student pickups and drop-offs ensuring students arrive at school on time and return home safely.</p>
          </div>
        </article>

        <article class="card">
          <!-- <img class="service-img" src="images/social_events.jpeg" alt="Social Events transportation"> -->
          <div class="card-body">
            <div class="badge_2"><i class="fa-solid fa-users"></i></div>
            <h3>Social Events</h3>
            <p>Convenient group transit for weddings, family gatherings, religious services, and community outings without parking stress.</p>
          </div>
        </article>

        <article class="card">
          <!-- <img class="service-img" src="images/workplaces.jpeg" alt="Workplaces transportation"> -->
          <div class="card-body">
            <div class="badge_2"><i class="fa-solid fa-briefcase"></i></div>
            <h3>Workplaces</h3>
            <p>Dependable commuter transport for corporate teams, shift workers, and recurring employee shuttle needs.</p>
          </div>
        </article>

      </div>
    </div>
  </section>

  <section class="mission" id="mission">
    <div class="container">
      <div class="pill-grid">
        <div class="pill"><div class="eyebrow_v2 text_18">Our Mission</div><h3>Safe. Reliable. Compassionate.</h3><p>Our mission is to provide safe, reliable, compassionate, and professional non-emergency medical transportation services while treating every passenger with dignity, respect, and care.</p></div>
        <div class="pill"><div class="eyebrow_v2 text_18">Our Vision</div><h3>A Trusted Transportation Experience</h3><p>Our vision is to become a trusted leader in non-emergency medical transportation by creating an experience where every passenger feels safe, valued, respected, and cared for.</p></div>
        <div class="pill"><div class="eyebrow_v2 text_18">Our Goals</div><h3>What We Work Toward</h3><ul><li>Safety First</li><li>Reliable & On-Time Service</li><li>Compassionate Customer Care</li><li>Accessibility</li><li>Professional Service</li><li>Strong Community Partnerships</li><li>Continuous Improvement</li></ul></div>
        <div class="pill"><div class="eyebrow_v2 text_18">Our Commitment</div><h3>Every Ride Matters</h3><p>We believe transportation is more than getting from one place to another. It is about helping people reach the care they need with safety, dignity, comfort, compassion, and peace of mind.</p><p><strong>Safe rides. Reliable service. Compassionate care.</strong></p></div>
      </div>
    </div>
  </section>

  <section id="why" class="why">
    <div class="container why-grid">
      <div>
        <div class="eyebrow">Why Choose Us</div>
        <h2>Why Choose <span>Selamta Transport?</span></h2>
        <p>At Selamta Transport LLC, we understand that transportation is an important part of accessing quality healthcare. We are committed to making every trip safe, comfortable, dependable, and respectful.</p>
      </div>
      <div class="reason-grid">
        <div class="reason"><div class="big">◉</div><b>Safe & Dependable Transportation</b><span>Your safety comes first.</span></div>
        <div class="reason"><div class="big">◷</div><b>Reliable & On-Time Service</b><span>Dependable pickup and drop-off.</span></div>
        <div class="reason"><div class="big">♡</div><b>Compassionate Care</b><span>Kindness, patience and dignity.</span></div>
        <div class="reason"><div class="big">♿</div><b>Passenger-Focused Service</b><span>Responsive to individual needs.</span></div>
        <div class="reason"><div class="big">★</div><b>Professional Service</b><span>Courtesy and communication.</span></div>
        <div class="reason"><div class="big">🤝</div><b>Trusted Community Partner</b><span>Strong community relationships.</span></div>
      </div>
    </div>
  </section>

  <section id="request">
    <div class="container request">
      <div class="panel">
        <div class="eyebrow_v2">Request a Service</div>
        <h2>Need Transportation?</h2>
        <p style="font-size:12px;color:var(--muted)">Fill out the form below and we'll get back to you as soon as possible.</p>
        <form id="request-form" method="post" action="add_request.php">
          <div class="form-grid">
            <div class="field"><label for="full_name">Full Name *</label><input id="full_name" name="full_name" required value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>"></div>
            <div class="field"><label for="phone">Phone Number *</label><input id="phone" name="phone" required type="tel" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>"></div>
            <div class="field"><label for="email">Email Address *</label><input id="email" name="email" required type="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"></div>
            <div class="field"><label for="service">Service Required *</label><select id="service" name="service" required>
              <option value="">Select a Service</option>
              <option value="Medical Appointment"<?php echo (($_POST['service'] ?? '') === 'Medical Appointment') ? ' selected' : ''; ?>>Medical Appointment</option>
              <option value="Dialysis Transportation"<?php echo (($_POST['service'] ?? '') === 'Dialysis Transportation') ? ' selected' : ''; ?>>Dialysis Transportation</option>
              <option value="Therapy & Rehabilitation"<?php echo (($_POST['service'] ?? '') === 'Therapy & Rehabilitation') ? ' selected' : ''; ?>>Therapy & Rehabilitation</option>
              <option value="Hospital & Clinic Transportation"<?php echo (($_POST['service'] ?? '') === 'Hospital & Clinic Transportation') ? ' selected' : ''; ?>>Hospital & Clinic Transportation</option>
              <option value="Hospital Discharge & Return"<?php echo (($_POST['service'] ?? '') === 'Hospital Discharge & Return') ? ' selected' : ''; ?>>Hospital Discharge & Return</option>
              <option value="Scheduled & Recurring Trips"<?php echo (($_POST['service'] ?? '') === 'Scheduled & Recurring Trips') ? ' selected' : ''; ?>>Scheduled & Recurring Trips</option>
              <option value="School Transportation"<?php echo (($_POST['service'] ?? '') === 'School Transportation') ? ' selected' : ''; ?>>School Transportation</option>
              <option value="Social Events Transportation"<?php echo (($_POST['service'] ?? '') === 'Social Events Transportation') ? ' selected' : ''; ?>>Social Events Transportation</option>
              <option value="Workplaces Transportation"<?php echo (($_POST['service'] ?? '') === 'Workplaces Transportation') ? ' selected' : ''; ?>>Workplaces Transportation</option>
            </select></div>
            <div class="field"><label for="pickup_location">Pickup Location *</label><input id="pickup_location" name="pickup_location" required value="<?php echo htmlspecialchars($_POST['pickup_location'] ?? ''); ?>"></div>
            <div class="field"><label for="dropoff_location">Drop off Location *</label><input id="dropoff_location" name="dropoff_location" required value="<?php echo htmlspecialchars($_POST['dropoff_location'] ?? ''); ?>"></div>
            <div class="field"><label for="pickup_date">Preferred Pickup Date *</label><input id="pickup_date" name="pickup_date" required type="date" value="<?php echo htmlspecialchars($_POST['pickup_date'] ?? ''); ?>"></div>
            <div class="field full"><label for="message">Message / Special Requirements</label><textarea id="message" name="message" placeholder="Tell us about mobility needs, recurring trips, or other requirements."><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea></div>
            <div class="field full"><input type="hidden" name="request_submit" value="1"><button class="btn dark" type="submit" style="width:100%">Click Here →</button></div>
          </div>
        </form>
        <p id="request-form-message" role="status" aria-live="polite" style="display:none;margin-top:14px;font-size:12px;font-weight:600;"></p>
      </div>
      <div class="panel"><div class="eyebrow_v2">Transportation</div><h2>Comfort & Accessibility</h2><p style="font-size:12px;color:var(--muted)">Wheelchair transportation is available based on vehicle availability and scheduling. Please contact us in advance for appropriate arrangements.</p>
        <img class="fleet-photo" src='images/selamta-ambulatory.jpg' alt="Selamta Transport vehicle">
        <div class="fleet-features"><div>♿<b>Wheelchair Accessible</b><span>Based on availability</span></div><div>●<b>Passenger Focused</b><span>Comfort & respect</span></div><div>✓<b>Reliable Service</b><span>Scheduled trips</span></div><div>★<b>Professional</b><span>Caring service</span></div></div>
      </div>
    </div>
  </section>

<section class="contact" id="contact"><div class="container contact-grid">
  <div class="contact-card"><div class="eyebrow_v2">Contact Us</div><h2>We're Here to Help</h2>
    <div class="contact-item"><div class="icon">☎</div><div><b>+1 913 568 0962</b><br><span style="color:var(--muted);font-size:11px"></span></div></div>
    <div class="contact-item"><div class="icon">✉</div><div><b>selamtatransport@gmail.com</b><br><span style="color:var(--muted);font-size:11px"></span></div></div>
    <div class="contact-item"><div class="icon">⌖</div><div><b>8747 Noland Rd, <br/>Lenexa, Ks 66215</b><br><span style="color:var(--muted);font-size:11px"></span></div></div>
  </div>
  <div class="contact-card">
    <div class="eyebrow_v2">Follow Us</div>
    <!-- <h2>Follow Us on</h2> -->
    <!-- <p style="color:var(--muted);font-size:13px">Connect with Selamta Transport LLC on social platforms.</p> -->
    <div class="social-big">
      <!-- <a href="#" aria-label="X">X</a>
      <a href="#" aria-label="Facebook">f</a>
      <a href="#" aria-label="LinkedIn">in</a>
      <a href="#" aria-label="Instagram">◎</a>
      <a href="#" aria-label="TikTok">♪</a> -->
      <a href="#" aria-label="X"><i class="fa-brands fa-x-twitter"></i></a>
      <a href="#" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
      <a href="#" aria-label="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
      <a href="#" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
      <a href="#" aria-label="TikTok"><i class="fa-brands fa-tiktok"></i></a>
    </div>
  </div>
</div></section>

  <!-- Service Area Banner -->
<section class="service-area-banner">
    <div class="container">
        <div class="service-area-content">
            <div class="service-area-icon">
                <i class="fas fa-map-marker-alt"></i>
            </div>

            <div>
                <h2>We Serve the Entire Kansas City Metro Area and Beyond</h2>
                <p>Reliable transportation where you need it, when you need it.</p>
            </div>
        </div>
    </div>
</section>

<footer class="footer"><div class="container">
  <div class="footer-grid">
    <!-- <div><a class="brand" href="#home"><span class="brand-mark">S</span><span class="brand-text"><strong>SELAMTA</strong><span>TRANSPORT LLC</span></span></a><p>Safe Rides • Reliable Service • Compassionate Care</p></div> -->
    <div><a class="brand" href="#home"><img src="images/logo_250.png" class="brand-mark_img"></img><span class="brand-text"><strong>SELAMTA</strong><span>TRANSPORT LLC</span></span></a><p>Safe Rides • Reliable Service • Compassionate Care</p></div>
    <div><h4>Quick Links</h4><a href="#home">Home</a><br><a href="#about">About Us</a><br><a href="#services">Services</a><br><a href="#why">Why Choose Us</a><br><a href="#contact">Contact</a></div>
    <div><h4>Our Services</h4><a href="#services">Medical Appointments</a><br><a href="#services">Dialysis Transportation</a><br><a href="#services">Wheelchair Transportation</a><br><a href="#services">Student Transportation</a><br><a href="#services">More Services</a></div>
    <div><h4>Contact Us</h4><p>☎ +1 913 568 0962</p><p>✉ selamtatransport@gmail.com</p><p>⌖ 8747 Noland Rd, Lenexa, Ks 66215</p></div>
  </div>
  <div class="copyright">© 2026 Selamta Transport LLC. All rights reserved. Designed by: <a target="_blank" href="https://wa.me/251920516314">Tekeste Demesie</a></div>
</div></footer>

<!-- <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script> -->
<script src="js/jquery-3.7.1.min.js"></script>
<script>
$(function () {
    $('#request-form').on('submit', function (event) {
        event.preventDefault();

        var form = $(this);
        var submitButton = form.find('button[type="submit"]');
        var status = $('#request-form-message');

        submitButton.prop('disabled', true).text('Sending...');
        status.hide().removeClass('success error').text('');

        $.post(form.attr('action'), form.serialize(), function (data) {
            var response;

            try {
                response = typeof data === 'string' ? JSON.parse(data) : data;
            } catch (error) {
                status.addClass('error').css('color', '#b42318')
                    .text('The server returned an invalid response. Please try again.')
                    .show();
                return;
            }

            if (response.success == 0) {
                status.addClass('error').css('color', '#b42318')
                    .text(response.message || 'Unable to submit your request.')
                    .show();
                return;
            }

            status.addClass('success').css('color', '#0d8a41')
                .text(response.message || 'Your request has been received.')
                .show();
            form[0].reset();
        }).fail(function () {
            status.addClass('error').css('color', '#b42318')
                .text('Failed to submit your request. Please call +1 913 568 0962.')
                .show();
        }).always(function () {
            submitButton.prop('disabled', false).text('Click Here →');
        });
    });
});
</script>
</body></html>